#include "stm32f10x.h"
#include "dht11.h"

// 定义DHT11引脚
#define DHT11_GPIO_PORT        GPIOA
#define DHT11_GPIO_PIN         GPIO_Pin_2
#define DHT11_RCC_CLOCK        RCC_APB2Periph_GPIOA

// 全局变量存储温湿度数据
uint8_t DHT11_Data[5] = {0};  // [湿度整数, 湿度小数, 温度整数, 温度小数, 校验和]

/* 微秒级延时函数（72MHz主频粗略延时） */
static void DHT11_Delay_us(uint32_t us) {
    us = us * 8;  // 根据实际时钟校准（72MHz下循环约8次/微秒）
    while (us--) {
        __NOP();
    }
}

/* DHT11 GPIO初始化 */
void DHT11_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct;
    
    // 1. 使能GPIOA时钟
    RCC_APB2PeriphClockCmd(DHT11_RCC_CLOCK, ENABLE);
    
    // 2. 配置PA2为推挽输出（默认高电平）
    GPIO_InitStruct.GPIO_Pin = DHT11_GPIO_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(DHT11_GPIO_PORT, &GPIO_InitStruct);
    
    // 3. 初始拉高总线
    GPIO_SetBits(DHT11_GPIO_PORT, DHT11_GPIO_PIN);
}

/* 启动DHT11并读取数据（返回0成功，其他值错误） */
uint8_t DHT11_Read(void) {
    uint8_t i, j, retry = 0;
    GPIO_InitTypeDef GPIO_InitStruct;
    
    // 1. 发送启动信号（拉低18ms）
    GPIO_InitStruct.GPIO_Pin = DHT11_GPIO_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(DHT11_GPIO_PORT, &GPIO_InitStruct);
    
    GPIO_ResetBits(DHT11_GPIO_PORT, DHT11_GPIO_PIN);  // 拉低总线
    DHT11_Delay_us(18000);                            // 保持18ms
    GPIO_SetBits(DHT11_GPIO_PORT, DHT11_GPIO_PIN);    // 释放总线
    
    // 2. 切换为输入模式等待响应
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(DHT11_GPIO_PORT, &GPIO_InitStruct);
    
    // 3. 检测DHT11响应（80us低电平 + 80us高电平）
    retry = 100;
    while (GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN) && retry) {
        retry--;
        DHT11_Delay_us(1);
    }
    if (!retry) return 1;  // 错误1：响应超时
    
    retry = 100;
    while (!GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN) && retry) {
        retry--;
        DHT11_Delay_us(1);
    }
    if (!retry) return 2;  // 错误2：响应错误
    
    // 4. 读取40位数据（高位在前）
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 8; j++) {
            // 等待50us低电平起始信号
            retry = 100;
            while (!GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN) && retry) {
                retry--;
                DHT11_Delay_us(1);
            }
            if (!retry) return 3;  // 错误3：数据位超时
            
            // 检测高电平持续时间判断0/1（26-28us为0，70us为1）
            DHT11_Delay_us(40);
            if (GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN)) {
                DHT11_Data[i] |= (1 << (7 - j));
                // 等待剩余高电平时间
                retry = 100;
                while (GPIO_ReadInputDataBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN) && retry) {
                    retry--;
                    DHT11_Delay_us(1);
                }
            }
        }
    }
    
    // 5. 校验数据（校验和 = 湿度+温度）
    if (DHT11_Data[4] != (DHT11_Data[0] + DHT11_Data[1] + DHT11_Data[2] + DHT11_Data[3])) {
        return 4;  // 错误4：校验和错误
    }
    
    // 6. 恢复GPIO为输出模式
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(DHT11_GPIO_PORT, &GPIO_InitStruct);
    GPIO_SetBits(DHT11_GPIO_PORT, DHT11_GPIO_PIN);
    
    return 0;  // 读取成功
}

/* 获取温度值（整数部分） */
float DHT11_GetTemp(void) {
    return (float)DHT11_Data[2];  // DHT11温度值为整数
}