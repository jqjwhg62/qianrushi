#include "stm32f10x.h"

// 定义LED引脚
#define GREEN_LED_GPIO_PORT    GPIOA
#define GREEN_LED_GPIO_PIN     GPIO_Pin_0
#define RED_LED_GPIO_PORT      GPIOA
#define RED_LED_GPIO_PIN       GPIO_Pin_1

// 呼吸灯参数（学号末位5对应2Hz）
#define BREATH_PERIOD_MS       500     // 呼吸周期500ms
#define BREATH_STEP_MS         10      // 亮度变化步长10ms
volatile uint16_t breath_ccr = 0;      // PWM比较寄存器值
volatile int8_t breath_dir = 1;        // 呼吸方向（1:递增，-1:递减）

/******************** 绿灯初始化（常亮控制）********************/
void GreenLED_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct;
    
    // 1. 使能GPIOA时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // 2. 配置PA0为推挽输出
    GPIO_InitStruct.GPIO_Pin = GREEN_LED_GPIO_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GREEN_LED_GPIO_PORT, &GPIO_InitStruct);
    
    // 3. 初始状态：绿灯亮（高电平驱动）
    GPIO_SetBits(GREEN_LED_GPIO_PORT, GREEN_LED_GPIO_PIN);
}

/******************** 红灯初始化（PWM呼吸灯）********************/
void RedLED_PWM_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct;
    TIM_TimeBaseInitTypeDef TIM_InitStruct;
    TIM_OCInitTypeDef TIM_OCInitStruct;
    
    // 1. 使能GPIOA和TIM3时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    
    // 2. 配置PA1为复用推挽输出（TIM3通道2）
    GPIO_InitStruct.GPIO_Pin = RED_LED_GPIO_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(RED_LED_GPIO_PORT, &GPIO_InitStruct);
    
    // 3. 配置TIM3基础参数（PWM频率=1KHz）
    TIM_InitStruct.TIM_Period = 999;          // ARR=999 → 1KHz@72MHz
    TIM_InitStruct.TIM_Prescaler = 71;        // 72MHz/(71+1)=1MHz
    TIM_InitStruct.TIM_ClockDivision = 0;
    TIM_InitStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_InitStruct);
    
    // 4. 配置PWM模式（通道2）
    TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStruct.TIM_Pulse = 0;           // 初始占空比0%（红灯灭）
    TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC2Init(TIM3, &TIM_OCInitStruct);
    
    // 5. 使能TIM3预装载
    TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM3, ENABLE);
    
    // 6. 配置TIM4用于呼吸灯亮度渐变（10ms中断）
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    TIM_InitStruct.TIM_Period = (72000000 / 1000 * BREATH_STEP_MS) / 7200 - 1; // 10ms中断
    TIM_InitStruct.TIM_Prescaler = 7200 - 1;
    TIM_TimeBaseInit(TIM4, &TIM_InitStruct);
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
    NVIC_EnableIRQ(TIM4_IRQn);
    TIM_Cmd(TIM4, ENABLE);
}

/******************** 呼吸灯控制函数 ********************/
void RedLED_BreathCtrl(FunctionalState state) {
    if (state == ENABLE) {
        TIM_Cmd(TIM3, ENABLE);  // 启动TIM3 PWM输出
        TIM_Cmd(TIM4, ENABLE);  // 启动TIM4中断控制亮度渐变
    } else {
        TIM_Cmd(TIM3, DISABLE);
        TIM_Cmd(TIM4, DISABLE);
        GPIO_ResetBits(RED_LED_GPIO_PORT, RED_LED_GPIO_PIN); // 确保红灯灭
    }
}

/******************** TIM4中断服务函数（亮度渐变控制）********************/
void TIM4_IRQHandler(void) {
    static uint16_t step_count = 0;
    if (TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET) {
        TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
        
        // 每10ms调整一次占空比
        step_count += BREATH_STEP_MS;
        if (step_count >= BREATH_PERIOD_MS / 2) {
            breath_dir *= -1;    // 方向反转（递增→递减）
            step_count = 0;
        }
        
        // 计算新占空比（线性变化）
        breath_ccr += breath_dir * (999 * BREATH_STEP_MS) / BREATH_PERIOD_MS;
        breath_ccr = (breath_ccr > 999) ? 999 : (breath_ccr < 0) ? 0 : breath_ccr;
        
        // 更新PWM比较值
        TIM_SetCompare2(TIM3, breath_ccr);
    }
}