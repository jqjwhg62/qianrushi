#include "stm32f10x.h"

// 呼吸灯参数定义（学号末位5对应2Hz）
#define PWM_FREQ          1000    // PWM基础频率（Hz）
#define BREATH_PERIOD     500     // 呼吸周期（ms）
#define BREATH_STEP_MS    10      // 亮度变化步长（ms）

volatile uint16_t pwm_ccr = 0;    // PWM比较寄存器值
volatile int8_t breath_dir = 1;   // 呼吸方向（1:递增，-1:递减）

/******************** PWM初始化函数 ********************/
void PWM_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct;
    TIM_TimeBaseInitTypeDef TIM_BaseInitStruct;
    TIM_OCInitTypeDef TIM_OCInitStruct;

    // 1. 使能时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  // GPIOA时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);   // TIM3时钟

    // 2. 配置PA1为复用推挽输出（TIM3通道2）
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;        // 复用推挽输出
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    // 3. 配置TIM3基础参数
    TIM_BaseInitStruct.TIM_Period = 999;               // ARR值（PWM周期）
    TIM_BaseInitStruct.TIM_Prescaler = 71;             // 预分频值（72MHz/(71+1)=1MHz）
    TIM_BaseInitStruct.TIM_ClockDivision = 0;
    TIM_BaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_BaseInitStruct);

    // 4. 配置PWM模式（通道2）
    TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStruct.TIM_Pulse = 0;                    // 初始占空比0%
    TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC2Init(TIM3, &TIM_OCInitStruct);

    // 5. 使能预装载
    TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM3, ENABLE);

    // 6. 配置TIM4用于呼吸灯控制（10ms中断）
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    TIM_TimeBaseInitTypeDef TIM4_Init;
    TIM4_Init.TIM_Period = 7200 - 1;                   // 72MHz/7200=10kHz
    TIM4_Init.TIM_Prescaler = 7200 - 1;                // 10kHz/7200≈1.388Hz（实际使用计算值）
    TIM4_Init.TIM_ClockDivision = 0;
    TIM4_Init.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM4, &TIM4_Init);
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
    NVIC_EnableIRQ(TIM4_IRQn);
    TIM_Cmd(TIM4, ENABLE);

    // 7. 启动TIM3
    TIM_Cmd(TIM3, ENABLE);
}

/******************** 呼吸灯控制函数 ********************/
void PWM_BreathCtrl(FunctionalState state) {
    if(state == ENABLE) {
        TIM_Cmd(TIM3, ENABLE);
        TIM_Cmd(TIM4, ENABLE);
    } else {
        TIM_Cmd(TIM3, DISABLE);
        TIM_Cmd(TIM4, DISABLE);
        GPIO_ResetBits(GPIOA, GPIO_Pin_1);  // 确保LED熄灭
    }
}

/******************** TIM4中断服务函数 ********************/
void TIM4_IRQHandler(void) {
    static uint16_t step_counter = 0;
    
    if(TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET) {
        TIM_ClearITPendingBit(TIM4, TIM_IT_Update);

        // 每10ms更新一次CCR值
        step_counter += BREATH_STEP_MS;
        if(step_counter >= BREATH_PERIOD/2) {
            breath_dir *= -1;    // 方向反转
            step_counter = 0;
        }

        // 计算新占空比（线性变化）
        pwm_ccr += breath_dir * (999 * 2 * BREATH_STEP_MS) / BREATH_PERIOD;
        pwm_ccr = (pwm_ccr > 999) ? 999 : (pwm_ccr < 0) ? 0 : pwm_ccr;
        
        // 更新PWM占空比
        TIM_SetCompare2(TIM3, pwm_ccr);
    }
}