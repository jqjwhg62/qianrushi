#include "stm32f10x.h"
#include "Delay.h"
#include "LED.h"
#include "Serial.h"
#include "PWM.h"
#include "Key.h"


#include "stm32f10x.h"
#include "dht11.h"
#include "pwm.h"
#include "stdio.h"

// 全局变量定义
volatile float temperature = 0.0;       // 当前温度值
volatile float threshold = 35.0;        // 初始阈值（学号末位5对应35℃）
volatile uint8_t uart_cmd[2] = {0};     // 串口指令缓存

// 硬件初始化函数
void System_Init(void) {
    // 1. 系统时钟配置（72MHz）
    SystemInit();
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

    // 2. 外设初始化
    DHT11_Init();     // 温度传感器初始化
    PWM_Init();       // PWM呼吸灯初始化（PA1）
    USART1_Init();    // 串口初始化（9600bps）
    KEY_Init();       // 按键中断初始化（PA8）

    // 3. 默认状态：绿灯常亮
    GPIO_SetBits(GPIOA, GPIO_Pin_0);  // 绿灯亮
}

// 主程序逻辑
int main(void) {
    System_Init();  // 系统初始化

    while(1) {
        // 1. 温度采集与处理
        if (DHT11_Read() == 0) {  // 成功读取温度
            temperature = DHT11_GetTemp();

            // 2. 超阈值判断与LED控制
            if (temperature > threshold) {
                PWM_BreathCtrl(ENABLE);         // 红灯呼吸灯启动
                GPIO_ResetBits(GPIOA, GPIO_Pin_0); // 绿灯灭
            } else {
                PWM_BreathCtrl(DISABLE);        // 红灯关闭
                GPIO_SetBits(GPIOA, GPIO_Pin_0);   // 绿灯亮
            }

      
        }
        Delay_ms(2000);  // DHT11最小采样间隔2秒
    }
}

// 按键中断服务函数（切换阈值）
void EXTI9_5_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line8) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line8);  // 清除中断标志

        // 循环切换阈值：35℃→25℃→30℃
        static uint8_t idx = 0;
        const float thresholds[] = {35.0, 25.0, 30.0};
        threshold = thresholds[idx];
        idx = (idx + 1) % 3;

        // 通过串口发送新阈值
        printf("New Threshold: %.1f°C\r\n", threshold);
    }
}

// 串口接收中断服务函数
void USART1_IRQHandler(void) {
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {
        static uint8_t cnt = 0;
        uart_cmd[cnt++] = USART_ReceiveData(USART1);
        if (cnt >= 2) {  // 接收满2字节指令
            cnt = 0;
        }
    }
}
